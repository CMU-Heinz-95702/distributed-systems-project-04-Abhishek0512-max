//Name : Abhishek Venkatadri
//Andrew id : av3
//Used LLMs such as ChatGPT and Claude for coding
package ds.edu.mobileapplication;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import java.util.List;


public class DogAdapter extends RecyclerView.Adapter<DogAdapter.DogViewHolder> {
    // List to hold dog data items
    private List<DogItem> dogItems;

    // Constructor to initialize the adapter with data
    public DogAdapter(List<DogItem> dogItems) {
        this.dogItems = dogItems;
    }

    @NonNull
    @Override
    public DogViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each item
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_dog, parent, false);
        return new DogViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DogViewHolder holder, int position) {
        // Get the current dog item
        DogItem dogItem = dogItems.get(position);
        // Set text data
        holder.nameTextView.setText(dogItem.getName());
        holder.descriptionTextView.setText(dogItem.getDescription());

        // Load image if available
        if (!dogItem.getImageUrl().isEmpty()) {
            Picasso.get()
                    .load(dogItem.getImageUrl())
                    .placeholder(R.drawable.dog_placeholder)
                    .error(R.drawable.dog_placeholder)
                    .into(holder.imageView);
        } else {
            holder.imageView.setImageResource(R.drawable.dog_placeholder);
        }
    }

    @Override
    public int getItemCount() {
        // Return the size of the dataset
        return dogItems.size();
    }

    // Method to update data when new items are available
    public void updateDogs(List<DogItem> newDogItems) {
        this.dogItems = newDogItems;
        notifyDataSetChanged();
    }


    static class DogViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView nameTextView;
        TextView descriptionTextView;

        public DogViewHolder(@NonNull View itemView) {
            super(itemView);
            // Find and store views from the layout
            imageView = itemView.findViewById(R.id.dogImageView);
            nameTextView = itemView.findViewById(R.id.dogNameTextView);
            descriptionTextView = itemView.findViewById(R.id.dogDescriptionTextView);
        }
    }
}