//Name : Abhishek Venkatadri
//Andrew id : av3
//Used LLMs such as ChatGPT and Claude for coding
package ds.edu.mobileapplication;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The main activity for the Dog Breed App
 */
public class MainActivity extends AppCompatActivity {

    // UI Components
    private EditText searchInput;
    private Button searchButton;
    private Button randomButton;
    private RadioGroup searchTypeGroup;
    private RadioButton breedRadio;
    private RadioButton randomRadio;
    private RecyclerView resultsRecyclerView;
    private ProgressBar loadingIndicator;
    private TextView errorText;

    // Adapter for displaying dog data
    private DogAdapter dogAdapter;

    // Web service URL - replace with your actual deployed server URL
 //private static final String BASE_URL = "http://10.0.2.2:8080/Project4Task2_war_exploded";
 private static final String BASE_URL = "https://fuzzy-space-pancake-jj4pxvq6xgg6hw4x-8080.app.github.dev";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        initializeViews();

        // Set up RecyclerView
        setupRecyclerView();

        // Set up button listeners
        setupButtonListeners();
    }

    /**
     * Initialize all UI components
     */
    private void initializeViews() {
        searchInput = findViewById(R.id.searchInput);
        searchButton = findViewById(R.id.searchButton);
        randomButton = findViewById(R.id.randomButton);
        searchTypeGroup = findViewById(R.id.searchTypeGroup);
        breedRadio = findViewById(R.id.breedRadio);
        randomRadio = findViewById(R.id.randomRadio);
        resultsRecyclerView = findViewById(R.id.resultsRecyclerView);
        loadingIndicator = findViewById(R.id.loadingIndicator);
        errorText = findViewById(R.id.errorText);
    }

    /**
     * Set up RecyclerView with LinearLayoutManager and DogAdapter
     */
    private void setupRecyclerView() {
        resultsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        dogAdapter = new DogAdapter(new ArrayList<>());
        resultsRecyclerView.setAdapter(dogAdapter);
    }

    /**
     * Set up click listeners for buttons
     */
    private void setupButtonListeners() {
        searchButton.setOnClickListener(v -> {
            String query = searchInput.getText().toString().trim();
            if (TextUtils.isEmpty(query)) {
                Toast.makeText(MainActivity.this, "Please enter a search term", Toast.LENGTH_SHORT).show();
                return;
            }

            // Execute search based on selected type
            if (breedRadio.isChecked()) {
                searchForBreed(query);
            } else if (randomRadio.isChecked()) {
                getRandomDogs(query);
            } else {
                errorText.setText("Please select a search type");
                errorText.setVisibility(View.VISIBLE);
            }
        });

        randomButton.setOnClickListener(v -> getRandomDogs(null));
    }

    /**
     * Search for dog breeds
     * @param query The search query
     */
    private void searchForBreed(String query) {
        showLoading(true);
        errorText.setVisibility(View.GONE);

        try {
            // Construct the API endpoint
            String apiEndpoint = BASE_URL + "/api/breeds";

            new NetworkTask(
                    apiEndpoint,
                    new NetworkTask.NetworkCallback() {
                        @Override
                        public void onSuccess(String result) {
                            runOnUiThread(() -> {
                                showLoading(false);
                                try {
                                    processBreedSearchResult(result, query);
                                } catch (JSONException e) {
                                    onError("Error parsing response: " + e.getMessage());
                                }
                            });
                        }

                        @Override
                        public void onError(String errorMessage) {
                            runOnUiThread(() -> {
                                showLoading(false);
                                errorText.setText("Error: " + errorMessage);
                                errorText.setVisibility(View.VISIBLE);
                            });
                        }
                    }
            ).execute();

        } catch (Exception e) {
            showLoading(false);
            errorText.setText("Error: " + e.getMessage());
            errorText.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Process breed search results
     * @param jsonResponse JSON response from the server
     * @param query Search query to filter breeds
     */
    private void processBreedSearchResult(String jsonResponse, String query) throws JSONException {
        List<DogItem> dogItems = new ArrayList<>();

        JSONArray breedsArray = new JSONArray(jsonResponse);

        for (int i = 0; i < breedsArray.length(); i++) {
            JSONObject breedObject = breedsArray.getJSONObject(i);

            // Check if the breed matches the search query (case-insensitive)
            String breedName = breedObject.optString("name", "").toLowerCase(Locale.ROOT);
            if (query == null || breedName.contains(query.toLowerCase(Locale.ROOT))) {
                DogItem dogItem = new DogItem();
                dogItem.setName(breedObject.optString("name", "Unknown"));
                dogItem.setTemperament(breedObject.optString("temperament", "Not specified"));

                // Set other properties
                dogItem.setLifeSpan(breedObject.optString("life_span", ""));
                dogItem.setBreedGroup(breedObject.optString("breed_group", ""));

                // Handle weight
                if (breedObject.has("weight")) {
                    JSONObject weightObj = breedObject.getJSONObject("weight");
                    dogItem.setWeight(weightObj.optString("imperial", "Unknown") + " lbs");
                }

                // Handle height
                if (breedObject.has("height")) {
                    JSONObject heightObj = breedObject.getJSONObject("height");
                    dogItem.setHeight(heightObj.optString("imperial", "Unknown") + " inches");
                }

                // Handle image URL
                if (breedObject.has("reference_image_id")) {
                    String imageId = breedObject.getString("reference_image_id");
                    dogItem.setImageUrl("https://cdn2.thedogapi.com/images/" + imageId + ".jpg");
                }

                dogItems.add(dogItem);
            }
        }

        if (dogItems.isEmpty()) {
            errorText.setText("No breeds found matching your search");
            errorText.setVisibility(View.VISIBLE);
        } else {
            dogAdapter.updateDogs(dogItems);
        }
    }

    /**
     * Get random dog images
     * @param limit Number of random dogs to retrieve (null for default)
     */
    private void getRandomDogs(String limit) {
        showLoading(true);
        errorText.setVisibility(View.GONE);

        // Determine the limit of random dogs
        String queryLimit = limit != null && !limit.isEmpty() ? limit : "5";

        // Construct the API endpoint
        String apiEndpoint = BASE_URL + "/api/?limit=" + queryLimit;

        new NetworkTask(
                apiEndpoint,
                new NetworkTask.NetworkCallback() {
                    @Override
                    public void onSuccess(String result) {
                        runOnUiThread(() -> {
                            showLoading(false);
                            try {
                                processRandomDogsResult(result);
                            } catch (JSONException e) {
                                onError("Error parsing response: " + e.getMessage());
                            }
                        });
                    }

                    @Override
                    public void onError(String errorMessage) {
                        runOnUiThread(() -> {
                            showLoading(false);
                            errorText.setText("Error: " + errorMessage);
                            errorText.setVisibility(View.VISIBLE);
                        });
                    }
                }
        ).execute();
    }

    /**
     * Process random dogs results
     * @param jsonResponse JSON response from the server
     */
    private void processRandomDogsResult(String jsonResponse) throws JSONException {
        List<DogItem> dogItems = new ArrayList<>();

        JSONArray dogsArray = new JSONArray(jsonResponse);

        for (int i = 0; i < dogsArray.length(); i++) {
            JSONObject dogObject = dogsArray.getJSONObject(i);

            DogItem dogItem = new DogItem();

            // Set image URL
            String imageUrl = dogObject.optString("url", "");
            dogItem.setImageUrl(imageUrl);

            // Try to get breed information
            if (dogObject.has("breeds") && !dogObject.getJSONArray("breeds").isNull(0)) {
                JSONObject breedInfo = dogObject.getJSONArray("breeds").getJSONObject(0);

                dogItem.setName(breedInfo.optString("name", "Random Dog #" + (i + 1)));
                dogItem.setTemperament(breedInfo.optString("temperament", ""));
                dogItem.setLifeSpan(breedInfo.optString("life_span", ""));
                dogItem.setBreedGroup(breedInfo.optString("breed_group", ""));
            } else {
                dogItem.setName("Random Dog #" + (i + 1));
            }

            dogItems.add(dogItem);
        }

        if (dogItems.isEmpty()) {
            errorText.setText("No dog images found");
            errorText.setVisibility(View.VISIBLE);
        } else {
            dogAdapter.updateDogs(dogItems);
        }
    }

    /**
     * Show or hide loading indicator
     * @param show Whether to show or hide the loading indicator
     */
    private void showLoading(boolean show) {
        loadingIndicator.setVisibility(show ? View.VISIBLE : View.GONE);
        resultsRecyclerView.setVisibility(show ? View.GONE : View.VISIBLE);
    }
}