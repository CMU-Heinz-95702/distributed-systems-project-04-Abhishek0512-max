//Name : Abhishek Venkatadri
//Andrew id : av3
//Used LLMs such as ChatGPT and Claude for coding
package ds.edu.mobileapplication;
import android.os.AsyncTask;
import android.os.Build;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
public class NetworkTask extends AsyncTask<Void, Void, String> {

    private final String url; // The URL to connect to
    private final NetworkCallback callback; // Callback to return results
    private String errorMessage; // Stores error messages if request fails

    //url The URL to connect to
    //callback The interface implementation to receive results
    public NetworkTask(String url, NetworkCallback callback) {
        this.url = url;
        this.callback = callback;
    }
    //Called before background task begins
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }
    //The response string from the server or null if error occurs
    @Override
    protected String doInBackground(Void... voids) {
        HttpURLConnection connection = null;
        BufferedReader reader = null;

        try {
            // Set up the connection
            URL apiUrl = new URL(url);
            connection = (HttpURLConnection) apiUrl.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("User-Agent", "DogBreedApp Android/" + Build.VERSION.RELEASE);
            connection.setReadTimeout(30000);
            connection.setConnectTimeout(30000);
            connection.connect();
            // Check if the response code indicates success
            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                errorMessage = "Server returned error code: " + responseCode;
                return null;
            }
            // Read the response data
            reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder result = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                result.append(line);
            }

            return result.toString();

        } catch (IOException e) {
            // Capture any network errors
            errorMessage = "Network error: " + e.getMessage();
            return null;
        } finally {
            // Clean up resources
            if (connection != null) {
                connection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    // Ignore
                }
            }
        }
    }

    @Override
    protected void onPostExecute(String result) {
        if (result != null) {
            callback.onSuccess(result);
        } else {
            callback.onError(errorMessage);
        }
    }

    public interface NetworkCallback {
        void onSuccess(String result);
        void onError(String errorMessage);
    }
}