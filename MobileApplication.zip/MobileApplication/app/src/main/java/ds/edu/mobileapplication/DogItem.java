//Name : Abhishek Venkatadri
//Andrew id : av3
//Used LLMs such as ChatGPT and Claude for coding
package ds.edu.mobileapplication;

//Model class representing a dog breed with its characteristics
public class DogItem {
    // Private member variables to store dog attributes
    private String name; // Name of the dog breed
    private String temperament;// Dog's typical behavioral traits
    private String lifeSpan;// Average lifespan of the breed
    private String weight;// Typical weight range
    private String height;// Typical height range
    private String breedGroup;// Classification group of the breed
    private String imageUrl;// URL to an image of the dog breed

    public DogItem() {
        // Default constructor
        this.name = "";
        this.temperament = "";
        this.lifeSpan = "";
        this.weight = "";
        this.height = "";
        this.breedGroup = "";
        this.imageUrl = "";
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTemperament() {
        return temperament;
    }

    public void setTemperament(String temperament) {
        this.temperament = temperament;
    }

    public String getLifeSpan() {
        return lifeSpan;
    }

    public void setLifeSpan(String lifeSpan) {
        this.lifeSpan = lifeSpan;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getBreedGroup() {
        return breedGroup;
    }

    public void setBreedGroup(String breedGroup) {
        this.breedGroup = breedGroup;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }


    public String getDescription() {
        StringBuilder description = new StringBuilder();

        if (!temperament.isEmpty()) {
            description.append("Temperament: ").append(temperament).append("\n");
        }

        if (!lifeSpan.isEmpty()) {
            description.append("Life Span: ").append(lifeSpan).append("\n");
        }

        if (!weight.isEmpty()) {
            description.append("Weight: ").append(weight).append("\n");
        }

        if (!height.isEmpty()) {
            description.append("Height: ").append(height).append("\n");
        }

        if (!breedGroup.isEmpty()) {
            description.append("Breed Group: ").append(breedGroup);
        }

        return description.toString();
    }
}
